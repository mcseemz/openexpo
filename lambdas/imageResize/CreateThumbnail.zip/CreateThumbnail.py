import boto3
import os
import sys
import uuid
from PIL import Image
import PIL.Image

s3_client = boto3.client('s3')

def resize_image(image_path, resized_path, width, height):
    with Image.open(image_path) as image:
        if image.mode in ("RGBA", "P"): image = image.convert("RGB")
        image.thumbnail((width, height))
        print('going to save')

        image.save(resized_path)

def handler(event, context):
    print(event)
    bucket = event['file']['bucket']
    #key = event['file']['prefix'] + event['file']['fileName']
    key = event['file']['fileName']
    download_path = key

    ext = key[key.rfind('.'):]
    filename=key[:key.rfind('.')]
    #upload_path = filename +'.' + event['width'] + 'x' + event['height'] + ext
    upload_path = filename +'.' + event['width'] + 'x' + event['height'] + ext
    
    download_path = '/tmp/{}'.format(event['file']['fileName'])
    upload_path = '/tmp/{}'.format(filename +'.' + event['width'] + 'x' + event['height'] + ext)
    
    print('download_path: ' + download_path)
    print('upload_path: ' + upload_path)
    
    extra_args = {'CacheControl': 'max-age=86400'}
    
    s3_client.download_file(bucket, event['file']['prefix'] + event['file']['fileName'], download_path)
    resize_image(download_path, upload_path, int(event['width']), int(event['height']))
    s3_client.upload_file(upload_path, bucket, event['file']['prefix'] + filename +'.' + event['width'] + 'x' + event['height'] + ext, extra_args)
